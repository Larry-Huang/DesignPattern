﻿namespace Demo.Clip01
{
    class Clip01Demo : Common.Demo
    {
        protected override void Implementation()
        {
        }
    }
}
