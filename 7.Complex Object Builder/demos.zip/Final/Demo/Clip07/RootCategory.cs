﻿namespace Demo.Clip07
{
    sealed class RootCategory : Category
    {
        public RootCategory(int id, string name) : base(id, name)
        {
        }
    }
}