﻿namespace Demo.Clip07.Data
{
    public class DbBook
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public int CategoryId { get; set; }
    }
}
