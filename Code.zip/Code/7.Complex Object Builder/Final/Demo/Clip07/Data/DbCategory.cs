﻿namespace Demo.Clip07.Data
{
    public class DbCategory
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int? ParentId { get; set; }
    }
}
