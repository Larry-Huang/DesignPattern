﻿namespace Demo.Clip03.Names
{
    class Anonymous : Name
    {
        public override string Printable => "Anonymous";
    }
}