﻿namespace Demo.Clip02
{
    public abstract class Name
    {
        public abstract string Printable { get; }
    }
}