﻿namespace Demo.Clip02
{
    class Anonymous : Name
    {
        public override string Printable => "Anonymous";
    }
}