﻿namespace Demo.Clip06.Names
{
    class Anonymous : Name
    {
        public override string Printable => "Anonymous";
    }
}