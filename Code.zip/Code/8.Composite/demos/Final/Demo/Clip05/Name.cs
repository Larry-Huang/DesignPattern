﻿namespace Demo.Clip05
{
    public abstract class Name
    {
        public abstract string Printable { get; }
    }
}