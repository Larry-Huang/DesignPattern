﻿namespace Demo.Clip04
{
    public abstract class Name
    {
        public abstract string Printable { get; }
    }
}