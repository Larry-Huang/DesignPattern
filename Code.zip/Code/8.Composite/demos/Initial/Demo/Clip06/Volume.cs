﻿namespace Demo.Clip06
{
    public abstract class Volume
    {
        public abstract string GetLabel(string prefix, string suffix);
    }
}
