﻿using System.Collections.Generic;

namespace Demo.Clip01
{
    public interface IWithSimpleKeywords
    {
        IEnumerable<string> Keywords { get; }
    }
}
