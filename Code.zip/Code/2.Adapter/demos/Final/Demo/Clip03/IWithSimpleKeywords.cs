﻿using System.Collections.Generic;

namespace Demo.Clip03
{
    public interface IWithSimpleKeywords
    {
        IEnumerable<string> Keywords { get; }
    }
}