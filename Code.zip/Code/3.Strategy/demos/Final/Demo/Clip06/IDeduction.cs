﻿using Demo.Common;

namespace Demo.Clip06
{
    public interface IDeduction
    {
        Money From(Money a, Money b);
    }
}
