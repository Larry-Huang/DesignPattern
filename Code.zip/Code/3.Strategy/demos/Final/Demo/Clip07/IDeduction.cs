﻿using Demo.Common;

namespace Demo.Clip07
{
    public interface IDeduction
    {
        Money From(Money a, Money b);
    }
}
