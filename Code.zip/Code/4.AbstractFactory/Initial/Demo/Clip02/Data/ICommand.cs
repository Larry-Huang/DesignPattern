﻿namespace Demo.Clip02.Data
{
    public interface ICommand
    {
    }
}