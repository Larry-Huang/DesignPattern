﻿namespace Demo.Clip02
{
    class Clip02Demo : Common.Demo
    {
        protected override int ClipNumber { get; } = 2;

        protected override void Implementation()
        {
        }
    }
}
