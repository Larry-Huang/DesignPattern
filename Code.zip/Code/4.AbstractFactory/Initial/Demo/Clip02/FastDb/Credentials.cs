﻿namespace Demo.Clip02.FastDb
{
    public abstract class Credentials
    {
    }
}
