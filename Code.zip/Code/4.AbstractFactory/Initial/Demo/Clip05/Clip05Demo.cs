﻿namespace Demo.Clip05
{
    class Clip05Demo : Demo.Common.Demo
    {
        protected override int ClipNumber { get; } = 5;

        protected override void Implementation()
        {
        }
    }
}
