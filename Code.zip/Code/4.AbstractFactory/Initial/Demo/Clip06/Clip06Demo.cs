﻿using System;
using Demo.Clip06.CheapDb;
using Demo.Clip06.Data;
using Demo.Clip06.FastDb;

namespace Demo.Clip06
{
    class Clip06Demo : Demo.Common.Demo
    {
        protected override int ClipNumber { get; } = 6;

        protected override void Implementation()
        {

        }
    }
}
