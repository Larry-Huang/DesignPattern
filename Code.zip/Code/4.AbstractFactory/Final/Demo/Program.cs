﻿using System;
using Demo.Clip06;

namespace Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            new Clip06Demo().Run();

            Console.WriteLine();
            Console.Write("Press ENTER to continue . . . ");
            Console.ReadLine();
        }
    }
}
