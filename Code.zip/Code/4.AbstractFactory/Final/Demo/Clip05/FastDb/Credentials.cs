﻿namespace Demo.Clip05.FastDb
{
    public abstract class Credentials
    {
    }
}
