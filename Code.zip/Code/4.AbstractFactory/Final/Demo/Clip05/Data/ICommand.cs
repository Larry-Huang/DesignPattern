﻿namespace Demo.Clip05.Data
{
    public interface ICommand
    {

    }
}