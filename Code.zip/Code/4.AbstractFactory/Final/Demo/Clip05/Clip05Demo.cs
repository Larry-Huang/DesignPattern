﻿namespace Demo.Clip05
{
    class Clip05Demo : Common.Demo
    {
        protected override int ClipNumber { get; } = 6;

        protected override void Implementation()
        {
        }
    }
}
