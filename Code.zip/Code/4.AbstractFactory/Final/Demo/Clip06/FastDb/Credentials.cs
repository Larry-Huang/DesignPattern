﻿namespace Demo.Clip06.FastDb
{
    public abstract class Credentials
    {
    }
}
