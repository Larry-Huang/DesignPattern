﻿namespace Demo.Clip06.Data
{
    public interface ICommand
    {

    }
}