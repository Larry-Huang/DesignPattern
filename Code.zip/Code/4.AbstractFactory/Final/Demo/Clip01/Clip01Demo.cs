﻿namespace Demo.Clip01
{
    class Clip01Demo : Common.Demo
    {
        protected override int ClipNumber { get; } = 1;
        protected override void Implementation()
        {

        }
    }
}
