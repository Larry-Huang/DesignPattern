﻿namespace Demo.Clip01.FastDb
{
    public abstract class Credentials
    {
    }
}
