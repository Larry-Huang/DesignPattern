﻿namespace Demo.Clip01.Data
{
    public interface ICommand
    {

    }
}