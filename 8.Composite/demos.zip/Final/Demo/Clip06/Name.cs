﻿namespace Demo.Clip06
{
    public abstract class Name
    {
        public abstract string Printable { get; }
    }
}