﻿namespace Demo.Clip04.Names
{
    class Anonymous : Name
    {
        public override string Printable => "Anonymous";
    }
}