﻿namespace Demo.Clip03
{
    public abstract class Name
    {
        public abstract string Printable { get; }
    }
}