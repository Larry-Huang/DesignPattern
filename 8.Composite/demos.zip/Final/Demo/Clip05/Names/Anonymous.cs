﻿namespace Demo.Clip05.Names
{
    class Anonymous : Name
    {
        public override string Printable => "Anonymous";
    }
}