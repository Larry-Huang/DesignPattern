﻿using Demo.Common;

namespace Demo.Clip04
{
    public interface IPriceModifier
    {
        Money ApplyTo(Money price);
    }
}
