﻿using System;
using Demo.Common;

namespace Demo.Clip03
{
    class Clip03Demo : Common.Demo
    {
        protected override int ClipNumber { get; } = 3;

        protected override void Implementation()
        {
            this.Apply(TakeTwoOffer.GetOneFree());
            this.Apply(TakeTwoOffer.Deduct(new Money(7, new Currency("USD"))));
        }

        private void Apply(TakeTwoOffer offer)
        {
            Book first = new Book(
                "Design Patterns: Elements of Reusable Object-oriented Software",
                new Money(35, new Currency("USD")));
            Book second = new Book(
                "The Little Prince",
                new Money(9, new Currency("USD")));

            var cart = offer.ApplyTo(first, second);

            Console.WriteLine();
            Console.WriteLine(cart.first);
            Console.WriteLine(cart.second);
        }
    }
}
