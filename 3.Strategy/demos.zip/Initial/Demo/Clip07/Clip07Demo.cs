﻿namespace Demo.Clip07
{
    class Clip07Demo : Common.Demo
    {
        protected override int ClipNumber { get; } = 7;

        protected override void Implementation()
        {
        }
    }
}
