﻿using System.Collections.Generic;

namespace Demo.Clip04
{
    public interface IWithSimpleKeywords
    {
        IEnumerable<string> Keywords { get; }
    }
}