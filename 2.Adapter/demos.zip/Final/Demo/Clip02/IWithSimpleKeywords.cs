﻿using System.Collections.Generic;

namespace Demo.Clip02
{
    public interface IWithSimpleKeywords
    {
        IEnumerable<string> Keywords { get; }
    }
}